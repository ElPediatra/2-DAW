<?php
//Rellenar al principio:
$cadena = "Rellenar Principio";
$cadena = str_pad($cadena, 20, "#", STR_PAD_LEFT);
echo $cadena;
?>