<?php
$frase="Si notas que la tortilla se desliza, un poco sólida, sobre la base de la sartén es que ya está cuajada y llega el momento de darle la vuelta";

$palabras=explode(" ", $frase);
echo $palabras[0] . " ". $palabras[1];
?>