<?php //Muestro la cadena de texto que me han pedido con echo
echo '<a href="/arbol/prueba.php" class="prueba" onmouseover="status=\'hola\'; return trae;">prueba de enlace</a>';
?>