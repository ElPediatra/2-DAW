<?php
//Rellenar al final:
$cadena = "Rellenar Final";
$cadena = str_pad($cadena, 20, "#", STR_PAD_RIGHT);
echo $cadena;
?>