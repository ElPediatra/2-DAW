<?php
//Opción 3: Eliminar los espacios y puntos antes y después del texto:
$cadena = " ... Hola a todos ... ";
$cadena = trim($cadena, ' .');
echo $cadena;
?>