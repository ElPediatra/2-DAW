<?php 


include_once("sesiones.php");
//Se cierra la sesión
cerrar_sesion();


?>
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
  <head>
       <SCRIPT LANGUAGE="javascript">
          location.href = "index.php"; 
       </SCRIPT>
</html>
