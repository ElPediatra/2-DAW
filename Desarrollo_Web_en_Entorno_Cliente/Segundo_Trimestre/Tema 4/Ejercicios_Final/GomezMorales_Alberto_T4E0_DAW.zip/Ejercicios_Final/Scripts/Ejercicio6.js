var str= "Aprende javaScript de 10 en Síntesis";
var m= str.search(/[S|t]/i);
console.log(m);
var n=str.search(/[0-9]/i);

console.log(n);

var a= str.search(/0+/i);
console.log(a);