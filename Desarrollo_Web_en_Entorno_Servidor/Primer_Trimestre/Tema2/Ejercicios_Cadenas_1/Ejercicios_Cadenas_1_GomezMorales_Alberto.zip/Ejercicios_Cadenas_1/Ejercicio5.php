<?php

$frase="Pagarás, pagarás, ya verás que pagarás";
echo(substr_count($frase, "a","á"));

//No hemos dado los arrays, se ha dicho que no se haga

?>

