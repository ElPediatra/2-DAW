function abrirVentana() {
    window.open("", "Nueva Ventana", "width=600,height=300"); //Uso window.open para crear la ventana y le indico las variables de ancho y alto
}