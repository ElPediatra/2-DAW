
    var str = "El sistema operativo más seguro es Android";
    var res = str.replace(/android/i, "Linux");
    document.getElementById("demo").innerHTML = res;
/*
Reemplaza una parte de la cadena.
 /android/i es una expresión regular que busca la palabra “android”
  en la cadena, sin importar si está en mayúsculas o minúsculas.



*/