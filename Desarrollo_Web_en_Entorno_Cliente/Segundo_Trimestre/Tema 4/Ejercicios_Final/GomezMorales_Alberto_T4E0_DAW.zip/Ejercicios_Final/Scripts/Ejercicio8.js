function mayuscula() {
    var texto = document.getElementById("texto");
    texto.value = texto.value.toUpperCase();
}