<?php
function textoNegrita($texto) {
    return "<b>$texto</b>";
}

echo textoNegrita('Hola, mundo!');  //Cambia a <b>Hola, mundo!</b>
?>