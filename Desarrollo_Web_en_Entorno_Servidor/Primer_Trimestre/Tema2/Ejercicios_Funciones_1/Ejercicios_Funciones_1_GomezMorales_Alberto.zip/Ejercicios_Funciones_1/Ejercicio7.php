<?php
function cuadrado($num) {
    return $num * $num;
}

function cubo($num) {
    return $num * $num * $num;
}

echo cuadrado(4);  //Tiene que mostrar 16
echo cubo(3);      //Tiene que mostrar 27
?>
