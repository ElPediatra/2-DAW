<!DOCTYPE html>
<html>
<head>
	<title>Binario y octal</title>
</head>
<body>
	<h1>Transoformar en binario y octal</h1>
	<?php
	$num = 420;
	printf("El número decimal es: %d /t", $num);
	printf("El número en binario es: %b /t", $num);
	printf("El número en octal es: %o /t", $num);
	?>
</body>
</html>
