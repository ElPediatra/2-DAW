<?php
//Opción 2: Eliminar los espacios y puntos después del texto:

$cadena = " ... Hola a todos ... ";
$cadena = rtrim($cadena, ' .');
echo $cadena;
?>